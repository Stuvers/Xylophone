Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - DANMITCH3LL ( https://freesound.org/people/DANMITCH3LL/ )

You can find this pack online at: https://freesound.org/people/DANMITCH3LL/packs/14220/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 232009__danmitch3ll__xylophone-sweep.wav
    * url: https://freesound.org/s/232009/
    * license: Attribution
  * 232008__danmitch3ll__xylophone-d1.wav
    * url: https://freesound.org/s/232008/
    * license: Attribution
  * 232007__danmitch3ll__xylophone-e1.wav
    * url: https://freesound.org/s/232007/
    * license: Attribution
  * 232006__danmitch3ll__xylophone-f.wav
    * url: https://freesound.org/s/232006/
    * license: Attribution
  * 232005__danmitch3ll__xylophone-g.wav
    * url: https://freesound.org/s/232005/
    * license: Attribution
  * 232004__danmitch3ll__xylophone-a.wav
    * url: https://freesound.org/s/232004/
    * license: Attribution
  * 232003__danmitch3ll__xylophone-b.wav
    * url: https://freesound.org/s/232003/
    * license: Attribution
  * 232002__danmitch3ll__xylophone-c.wav
    * url: https://freesound.org/s/232002/
    * license: Attribution
  * 232001__danmitch3ll__xylophone-c2.wav
    * url: https://freesound.org/s/232001/
    * license: Attribution


